.. index::
   single: Python Package Index (PyPI)
   single: PyPI; (see Python Package Index (PyPI))

.. _package-index:

*******************************
The Python Package Index (PyPI)
*******************************

The `Python Package Index (PyPI)`_ stores metadata describing distributions
packaged with distutils and other publishing tools, as well the distribution
archives themselves.

Detailed instructions on using PyPI at :ref:`distributing-index`.

.. _Python Package Index (PyPI): https://pypi.org
