<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>First</source>
        <translation>Primo</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Esempio di localizzazione</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometrica</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Lingua: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Obliqua</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Prospettica</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Secondo</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Terzo</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
