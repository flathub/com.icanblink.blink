
version = '3.10.1'
major = 3
minor = 10
micro = 1
release_level = 'final'
serial = 0
version_info = (major, minor, micro, release_level, serial)
