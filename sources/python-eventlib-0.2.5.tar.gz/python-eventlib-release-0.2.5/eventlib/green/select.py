__select = __import__('select')
error = __select.error
from eventlib.api import select
del __select

