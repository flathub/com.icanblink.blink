.. note::

   This document is being retained solely until the ``setuptools`` documentation
   at https://setuptools.readthedocs.io/en/latest/setuptools.html
   independently covers all of the relevant information currently included here.
