# Copyright (C) 2008-2012 AG Projects. See LICENSE for details

__version__ = '0.20.0'

class MSRPError(Exception):
    pass

