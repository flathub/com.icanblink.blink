
"""Package information"""

__project__ = "blink"
__summary__ = "Blink Qt"
__webpage__ = "http://icanblink.com/"

__version__ = "3.2.1"

__date__ = "February 14th 2020"

__author__ = "AG Projects"
__email__ = "support@ag-projects.com"

__license__ = "GPLv3"
__copyright__ = "Copyright 2010-2020 {}".format(__author__)
