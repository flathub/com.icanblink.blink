---
name: 'Request a new Feature'
about: 'Create a request for a new feature'
title: ''
labels: 'meta:feature-request'
assignees: ''

---

Before requesting a new feature make sure it hasn't been requested yet.
https://github.com/mpv-player/mpv/labels/meta%3Afeature-request

### Expected behavior of the wanted feature

### Alternative behavior of the wanted feature
