
version = '3.9.1'
major = 3
minor = 9
micro = 1
release_level = 'final'
serial = 0
version_info = (major, minor, micro, release_level, serial)
