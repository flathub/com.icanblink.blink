"""Example scripts for the dispatch project
"""
