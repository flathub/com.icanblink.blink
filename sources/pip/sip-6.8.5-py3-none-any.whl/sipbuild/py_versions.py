# SPDX-License-Identifier: BSD-2-Clause

# Copyright (c) 2024 Phil Thompson <phil@riverbankcomputing.com>


# The oldest supported minor version of Python v3.
OLDEST_SUPPORTED_MINOR = 8
