
version = '3.11.0'
major = 3
minor = 11
micro = 0
release_level = 'final'
serial = 0
version_info = (major, minor, micro, release_level, serial)
