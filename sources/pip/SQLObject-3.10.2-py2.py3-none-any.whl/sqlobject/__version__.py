
version = '3.10.2'
major = 3
minor = 10
micro = 2
release_level = 'final'
serial = 0
version_info = (major, minor, micro, release_level, serial)
