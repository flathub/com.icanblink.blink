===============
 API Reference
===============

Contents:

.. toctree::
   :maxdepth: 2

   specifications
   declarations
   adapters
   components
   common
   ro
