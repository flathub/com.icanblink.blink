Number Matchers
---------------

Matchers that perform numeric comparisons.


close_to
^^^^^^^^

.. automodule:: hamcrest.library.number.iscloseto

greater_than, greater_than_or_equal_to, less_than, less_than_or_equal_to
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: hamcrest.library.number.ordering_comparison
