Helpers
-------

Utilities for writing Matchers


hasmethod
^^^^^^^^^

.. automodule:: hamcrest.core.helpers.hasmethod

wrap_matcher
^^^^^^^^^^^^

.. automodule:: hamcrest.core.helpers.wrap_matcher
