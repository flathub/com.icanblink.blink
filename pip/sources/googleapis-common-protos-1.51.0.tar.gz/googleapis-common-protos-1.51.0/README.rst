=========================
Google APIs common protos
=========================

googleapis-common-protos contains the python classes generated from the common
protos in the googleapis_ repository.

.. _`googleapis`: https://github.com/google/googleapis
