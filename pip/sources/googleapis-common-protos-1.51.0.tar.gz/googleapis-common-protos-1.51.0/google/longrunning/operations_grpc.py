# This module is provided for backwards compatibility with
# googleapis-common-protos <= 1.5.0, where this was the import path.

from __future__ import absolute_import
from google.longrunning.operations_grpc_pb2 import *