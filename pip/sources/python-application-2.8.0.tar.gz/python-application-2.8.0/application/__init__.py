
"""Basic building blocks for python applications"""

from application.__info__ import __project__, __summary__, __webpage__, __version__, __author__, __email__, __license__, __copyright__
